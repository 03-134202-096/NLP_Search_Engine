RUN FROM SCRATCH

1: upload "code_file.ipynb" on google colab
2: upload "raw_data.csv" on google colab by pressing upload icon on google colab
3: Press "runtime" on the top bar and then select "run all"(takes time for training modal almost 20 to 25 mints)
4: Enter any querry about news(HAVE FUN)



DIRECTLY ENTER QUERRY

1: upload "code_file.ipynb" on google colab
2: upload "filtered_data.csv","news_lsi_model_mm","news_lsi_model_mm.index","news_tfidf_model_mm","news_tfidf_model_mm.index" on google colab by pressing upload icon on google colab
3: Directly run last 2 cells




















